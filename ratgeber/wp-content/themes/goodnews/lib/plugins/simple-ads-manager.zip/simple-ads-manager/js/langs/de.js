tinyMCE.addI18n("de,samb", {
  'Insert Advertisement': 'Insert Advertisement',
  'Select Advertisement Object': 'Select Advertisement Object',
  'Insert Single Ad': 'Insert Single Ad',
  'Insert Ads Place': 'Insert Ads Place',
  'Insert Ads Zone': 'Insert Ads Zone',
  'Insert Ads Block': 'Insert Ads Block'
});